******** INSTRUCTIONS ********

1) Open the Terminal Application

2) Copy and paste the following into the terminal and press enter: 
   chmod +x ~/Downloads/RedditWallpaper/src/setup.command; python ~/Downloads/RedditWallpaper/src/setup.command;

3) Now go into System Preferences > Desktop & Screen Saver and press the + button in the bottom left corner

4) You will be prompted to choose a folder, choose the new RedditWallpaper folder on your Desktop.

5) Lastly, make sure that the option to Change Picture is set in the same System Preferences view. Adjust the time to change as you desire.

DONE!!!!!!
