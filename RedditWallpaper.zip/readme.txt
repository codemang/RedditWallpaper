******** INSTRUCTIONS ********

1) Make sure the new RedditWallpaper folder that you just unzipped is in your downloads folder.

2) Open the Terminal Application

3) Copy and paste the following into the terminal and press enter: 
   chmod +x ~/Downloads/RedditWallpaper/src/setup.command; python ~/Downloads/RedditWallpaper/src/setup.command;

4) You may now delete the RedditWallpaper folder in your downloads folder if you wish.

5) Now go into System Preferences > Desktop & Screen Saver, make sure the Desktop tab is selected, and press the + button in the bottom left corner

6) You will be prompted to choose a folder, choose the new RedditWallpaper folder on your Desktop.

7) Still in the System Prefrence page, check the box specifying 'Change Picture'. This ensures your computer cycles through all the photos. Change the delay between photos as you desire. 

DONE!!!!!!
